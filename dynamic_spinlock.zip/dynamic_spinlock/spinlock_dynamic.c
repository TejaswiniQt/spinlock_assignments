#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/kdev_t.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include<linux/slab.h>        //kmalloc()
#include<linux/uaccess.h>     //copy_to/from_user()
#include <linux/proc_fs.h>    // proc file system
#include <linux/compiler.h>
#include <linux/types.h>
#include <linux/proc_ns.h>
#include <linux/kobject.h>
#include <linux/interrupt.h>
#include <linux/kthread.h> // therad 
#include <linux/delay.h>   // sleep 
#include <linux/sched.h>  
#define MEM_SIZE 1000 
 
spinlock_t my_spinlock; 
int count =0;

int  my_thread_handle(void *p);
int  my_thread_handle1(void *p);
struct task_struct * char_thread,*char_thread1;


/*
Thread handling functions
*/
int my_thread_handle(void *p)
{

	while(!kthread_should_stop())
	{
	       
		spin_lock(&my_spinlock);
		printk("In thread function1 count=%d\n",count++);
		spin_unlock(&my_spinlock);
		msleep(1000);
	}	
	return 0;
}


int my_thread_handle1(void *p)
{

	while(!kthread_should_stop())
	{
		spin_lock(&my_spinlock);
		printk("In thread function2 count=%d\n",count++);
		spin_unlock(&my_spinlock);
		msleep(1000);
	}	
	return 0;
}


int32_t value = 0;
dev_t dev = 0;
uint8_t *kernel_buffer =NULL;
static struct class *dev_class;
static struct cdev ts_cdev;
/*
** Function Prototypes
*/
static int      __init ts_driver_init(void);
static void     __exit ts_driver_exit(void);
static int      ts_open(struct inode *inode, struct file *file);
static int      ts_release(struct inode *inode, struct file *file);
static ssize_t  ts_read(struct file *filp, char __user *buf, size_t len,loff_t * off);
static ssize_t  ts_write(struct file *filp, const char *buf, size_t len, loff_t * off);
static long     ts_ioctl(struct file *file, unsigned int cmd, unsigned long arg);

/*
** This function will be called when we open the Device file
*/
static int ts_open(struct inode *inode, struct file *file)
{
	if((kernel_buffer = kmalloc(MEM_SIZE,GFP_KERNEL))==0)
	{
		printk(KERN_INFO "Cannot allocate memory in kernel\n");
		return -1;
	}
        pr_info("Device File Opened...!!!\n");
        return 0;
}
/*
** This function will be called when we close the Device file
*/
static int ts_release(struct inode *inode, struct file *file)
{
	kfree(kernel_buffer);
        pr_info("Device File Closed...!!!\n");
        return 0;
}
/*
** This function will be called when we read the Device file
*/
static ssize_t ts_read(struct file *filp, char __user *buf, size_t len, loff_t *off)
{
	int ret =0;
	//Copy the data from the kernel space to the user-space
    	ret = copy_to_user(buf, kernel_buffer, MEM_SIZE);
	if(ret > 0)
	{
		printk(KERN_INFO"writing data to user-space failed\n");
	}
	printk(KERN_INFO"Driver read function called .....\n");
	return 0;
}
/*
** This function will be called when we write the Device file
*/
static ssize_t ts_write(struct file *filp, const char __user *buf, size_t len, loff_t *off)
{
        int ret = 0;
	//Copy the data to kernel space from the user-space
	copy_from_user(kernel_buffer, buf, len);
	if(ret > 0)
	{
		printk(KERN_INFO"Copy the data to kernel space from the user-space\n");
	}
	printk(KERN_INFO"Driver write function called .... \n");
	return len;
}

 
/*
** File operation sturcture
*/
static struct file_operations fops =
{
        .owner          = THIS_MODULE,
        .read           = ts_read,
        .write          = ts_write,
        .open           = ts_open,
        .release        = ts_release,
};

/*
** Module Init function
*/
static int __init ts_driver_init(void)
{
        /*Allocating Major number*/
        if((alloc_chrdev_region(&dev, 0, 1, "ts_Dev")) <0){
                pr_err("Cannot allocate major number\n");
                return -1;
        }
        pr_info("Major = %d Minor = %d \n",MAJOR(dev), MINOR(dev));
 
        /*Creating cdev structure*/
        cdev_init(&ts_cdev,&fops);
 
        /*Adding character device to the system*/
        if((cdev_add(&ts_cdev,dev,1)) < 0){
            pr_err("Cannot add the device to the system\n");
            goto r_class;
        }
 
        /*Creating struct class*/
        if((dev_class = class_create(THIS_MODULE,"ts_class")) == NULL){
            pr_err("Cannot create the struct class\n");
            goto r_class;
        }
 
        /*Creating device*/
        if((device_create(dev_class,NULL,dev,NULL,"ts_device")) == NULL){
            pr_err("Cannot create the Device 1\n");
            goto r_device;
        }
        pr_info("__init: Driver Insert...Done!!!\n");
        
        //initializing spinlock
        spin_lock_init(&my_spinlock);
        
        char_thread = kthread_run(my_thread_handle, NULL, "therad1");

	if(char_thread)
	{
		printk("thread1 created successfully");
	}
	else
	{
		printk("thread1 created failed");
		goto r_device;
		 
	}

	char_thread1 = kthread_run(my_thread_handle1, NULL, "therad2");

	if(char_thread1)
	{
		printk("thread2 created successfully");
	}
	else
	{
		printk("thread2 created failed");
		goto r_device;
		 
	}
        return 0;
 
r_device:
        class_destroy(dev_class);
r_class:
        unregister_chrdev_region(dev,1);
        return -1;
}
/*
** Module exit function
*/
static void __exit ts_driver_exit(void)
{
        device_destroy(dev_class,dev);
        class_destroy(dev_class);
        cdev_del(&ts_cdev);
        unregister_chrdev_region(dev, 1);
        
        kthread_stop(char_thread);
	kthread_stop(char_thread1);
        pr_info("__exit: Driver Remove...Done!!!\n");
}
 
module_init(ts_driver_init);
module_exit(ts_driver_exit);
 
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Sample Thread Linux device driver using spinlock");


